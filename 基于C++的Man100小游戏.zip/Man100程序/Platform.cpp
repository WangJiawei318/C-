#include "Platform.h"
#include <iostream>

using namespace std;

Platform::Platform(int x, int y, int id, const wstring& imgPath, int spd)
    : GameElement(x, y, 95, 15), imagePath(imgPath), speed(spd), platformId(id) {
    // ����ƽ̨ͼ��
    loadimage(&platformImage, imagePath.c_str());
    cout << "Platform " << id << " created at position (" << x << ", " << y << ")" << endl;
}

Platform::~Platform() {
    // ƽ̨��������
    cout << "Platform " << platformId << " destroyed" << endl;
}

void Platform::update() {
    // ƽ̨�����ƶ�
    y -= speed;

    // ���ƽ̨�Ƴ���Ļ���������õ��ײ�
    if (y < 80) {
        y = 430;
        x = rand() % (390 - width);
    }

    // �߽���
    if (x < 40) x = 40;
    if (x > 325) x = 325;
}

void Platform::render() {
    if (isVisible) {
        putimage(x, y, &platformImage);
    }
}

