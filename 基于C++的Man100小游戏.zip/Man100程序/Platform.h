#pragma once

#ifndef PLATFORM_H
#define PLATFORM_H

#include "GameElement.h"
#include <string>
using namespace std;


class Platform : public GameElement {
private:
    wstring imagePath;      // ƽ̨ͼ��·��
    IMAGE platformImage;    // ƽ̨ͼ��
    int speed;              // �ƶ��ٶ�
    int platformId;         // ƽ̨ID


public:
    Platform(int x, int y, int id, const wstring& imgPath, int spd = 0);
    ~Platform();

    void update();
    void render();

    int getId() const { return platformId; }
    int getSpeed() const { return speed; }
    void setSpeed(int newSpeed) { speed = newSpeed; }

};

#endif