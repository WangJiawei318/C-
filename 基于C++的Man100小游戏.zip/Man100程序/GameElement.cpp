#include "GameElement.h"
#include <iostream>
using namespace std;

GameElement::GameElement(int x, int y, int w, int h)
    : x(x), y(y), width(w), height(h), isVisible(true) {
}

GameElement::~GameElement() {
    
}

bool GameElement::checkCollision(const GameElement& other) const {
    return !(x + width < other.x ||
        y + height < other.y ||
        other.x + other.width < x ||
        other.y + other.height < y);
}