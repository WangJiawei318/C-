#include "GameFrame.h"
#include <iostream>
using namespace std;

int main() {
    cout << "Starting Man100 Game..." << endl;

    // ������Ϸ���
    GameFrame game(632, 430, 50); 

    // ��ʼ����Ϸ
    if (!game.init()) {
        cout << "Failed to initialize game!" << endl;
        return -1;
    }

    // ������Ϸ
    game.run();

    closegraph();
    cout << "Game exited normally" << endl;
    return 0;
}